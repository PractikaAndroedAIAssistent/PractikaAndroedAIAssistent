# Реализованный следующий шаг: функционал модулей, локальная БД и тесты

## Важно

В этой версии я специально не добавлял Room/KSP-зависимости, чтобы проект не упал на вашем закрытом Nexus. Вместо этого сделан полноценный учебный data layer:

- `InMemoryAppDatabase` — локальная учебная БД в памяти;
- repository-классы для всех основных модулей;
- domain-модели;
- unit-тесты для каждого модуля.

Позже `InMemoryAppDatabase` можно заменить на Room: domain-модели, репозитории и тестовая логика уже разложены по слоям.

## Добавленные модули

1. `subjects` — предметы.
2. `schedule` — расписание.
3. `deadlines` — дедлайны.
4. `notes` — конспекты.
5. `pdf` — PDF-файлы и чанки текста.
6. `ai` — fake AI-сервис: суммаризация, чат по PDF, генерация тестов и карточек.
7. `studytests` — тесты, вопросы, варианты ответов, попытки прохождения.
8. `flashcards` — наборы карточек и интервальное повторение.
9. `grades` — оценки и аналитика.
10. `notifications` — уведомления.
11. `imports` — демо-импорт из ЛК/файла.

## Главная точка подключения

```kotlin
val container = StudentAssistantContainer()
```

Файл:

```text
app/src/main/java/com/example/studentassistant/core/database/StudentAssistantContainer.kt
```

## Локальная БД

Файл:

```text
app/src/main/java/com/example/studentassistant/core/database/InMemoryAppDatabase.kt
```

В ней хранятся списки:

```text
subjects
scheduleItems
deadlines
notes
pdfFiles
pdfChunks
aiRequests
aiResponses
chatMessages
studyTests
testAttempts
flashcardSets
flashcards
grades
notifications
importSources
importLogs
```

## Unit-тесты

Файлы лежат здесь:

```text
app/src/test/java/com/example/studentassistant/feature/modules/
```

Добавлены тесты:

- `SubjectModuleTest`
- `ScheduleModuleTest`
- `DeadlineModuleTest`
- `NotesModuleTest`
- `PdfAiModuleTest`
- `StudyTestModuleTest`
- `FlashcardModuleTest`
- `GradesAnalyticsModuleTest`
- `NotificationModuleTest`
- `ImportModuleTest`

Плюс остались тесты авторизации:

```text
app/src/test/java/com/example/studentassistant/feature/auth/
```

## Как запускать тесты

В Android Studio:

```text
ПКМ по папке app/src/test → Run Tests
```

Или через Gradle:

```bash
gradlew test
```

## Что можно делать дальше

Следующий правильный этап:

1. Подключить эти репозитории к ViewModel экранов.
2. Сделать формы добавления предмета, пары, дедлайна, конспекта.
3. Заменить `InMemoryAppDatabase` на Room, когда будет понятно, какие версии зависимостей есть в Nexus.
4. Добавить экран PDF-чата и генерации тестов/карточек.
