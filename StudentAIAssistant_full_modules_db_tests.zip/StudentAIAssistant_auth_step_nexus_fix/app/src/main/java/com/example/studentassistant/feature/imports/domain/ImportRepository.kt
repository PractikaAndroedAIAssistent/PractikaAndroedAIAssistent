package com.example.studentassistant.feature.imports.domain

interface ImportRepository {
    fun createSource(userId: Long, type: ImportSourceType, title: String, url: String? = null): UniversityImportSource
    fun importDemoData(sourceId: Long, userId: Long, subjectId: Long): ImportLog
    fun getLogs(sourceId: Long): List<ImportLog>
}
