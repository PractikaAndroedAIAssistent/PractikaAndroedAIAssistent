package com.example.studentassistant.feature.flashcards.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.flashcards.domain.Flashcard
import com.example.studentassistant.feature.flashcards.domain.FlashcardRepository
import com.example.studentassistant.feature.flashcards.domain.FlashcardSet
import com.example.studentassistant.feature.flashcards.domain.KnowledgeLevel

class InMemoryFlashcardRepository(private val db: InMemoryAppDatabase) : FlashcardRepository {
    override fun createSet(userId: Long, subjectId: Long?, title: String): FlashcardSet {
        require(title.isNotBlank()) { "Название набора не может быть пустым" }
        return FlashcardSet(db.nextId(), userId, subjectId, title.trim()).also { db.flashcardSets.add(it) }
    }

    override fun addCard(setId: Long, question: String, answer: String): Flashcard {
        require(question.isNotBlank()) { "Вопрос карточки не может быть пустым" }
        require(answer.isNotBlank()) { "Ответ карточки не может быть пустым" }
        return Flashcard(db.nextId(), setId, question.trim(), answer.trim()).also { db.flashcards.add(it) }
    }

    override fun getSets(userId: Long): List<FlashcardSet> = db.flashcardSets.filter { it.userId == userId }.sortedBy { it.title }
    override fun getCards(setId: Long): List<Flashcard> = db.flashcards.filter { it.setId == setId }

    override fun getDueCards(userId: Long, day: Int): List<Flashcard> {
        val setIds = getSets(userId).map { it.id }.toSet()
        return db.flashcards.filter { it.setId in setIds && it.nextReviewDay <= day }
    }

    override fun reviewCard(cardId: Long, level: KnowledgeLevel, currentDay: Int): Flashcard? {
        val index = db.flashcards.indexOfFirst { it.id == cardId }
        if (index == -1) return null
        val addDays = when (level) {
            KnowledgeLevel.DONT_KNOW -> 0
            KnowledgeLevel.BAD -> 1
            KnowledgeLevel.NORMAL -> 3
            KnowledgeLevel.GOOD -> 7
            KnowledgeLevel.EXCELLENT -> 14
        }
        val updated = db.flashcards[index].copy(knowledgeLevel = level, nextReviewDay = currentDay + addDays)
        db.flashcards[index] = updated
        return updated
    }
}
