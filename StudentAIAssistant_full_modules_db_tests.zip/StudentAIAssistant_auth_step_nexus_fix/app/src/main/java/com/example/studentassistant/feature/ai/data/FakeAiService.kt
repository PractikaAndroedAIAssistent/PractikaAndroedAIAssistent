package com.example.studentassistant.feature.ai.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.ai.domain.AiRequest
import com.example.studentassistant.feature.ai.domain.AiRequestType
import com.example.studentassistant.feature.ai.domain.AiResponse
import com.example.studentassistant.feature.ai.domain.AiService
import com.example.studentassistant.feature.flashcards.domain.Flashcard
import com.example.studentassistant.feature.studytests.domain.AnswerOption
import com.example.studentassistant.feature.studytests.domain.QuestionType
import com.example.studentassistant.feature.studytests.domain.StudyTest
import com.example.studentassistant.feature.studytests.domain.TestQuestion

class FakeAiService(private val db: InMemoryAppDatabase) : AiService {
    override fun summarize(userId: Long, sourceId: Long?, text: String): AiResponse {
        val request = AiRequest(db.nextId(), userId, AiRequestType.SUMMARY, sourceId, "Суммаризируй текст")
        db.aiRequests.add(request)
        val sentences = text.split('.', '!', '?').map { it.trim() }.filter { it.isNotBlank() }
        val summary = if (sentences.isEmpty()) "Недостаточно текста для суммаризации." else sentences.take(3).joinToString(". ") + "."
        return AiResponse(db.nextId(), request.id, summary).also { db.aiResponses.add(it) }
    }

    override fun answerByPdf(userId: Long, pdfFileId: Long, question: String): AiResponse {
        val request = AiRequest(db.nextId(), userId, AiRequestType.PDF_CHAT, pdfFileId, question)
        db.aiRequests.add(request)
        val words = question.lowercase().split(" ", ".", ",", "?", "!").filter { it.length > 3 }
        val chunks = db.pdfChunks.filter { it.pdfFileId == pdfFileId }
        val found = chunks.firstOrNull { chunk -> words.any { chunk.text.lowercase().contains(it) } }
        val answer = found?.let { "По загруженному PDF найдено: ${it.text.take(260)}" }
            ?: "В загруженном материале нет достаточной информации для ответа на этот вопрос."
        return AiResponse(db.nextId(), request.id, answer).also { db.aiResponses.add(it) }
    }

    override fun generateTest(userId: Long, subjectId: Long?, title: String, sourceText: String, questionsCount: Int): StudyTest {
        val testId = db.nextId()
        val terms = sourceText.split(" ", "\n", ".", ",", ";", ":").map { it.trim() }.filter { it.length >= 5 }.distinct().take(questionsCount.coerceAtLeast(1))
        val questions = terms.mapIndexed { index, term ->
            val qId = db.nextId()
            val correct = AnswerOption(db.nextId(), qId, term, true)
            val wrong = AnswerOption(db.nextId(), qId, "Нет правильного ответа", false)
            TestQuestion(qId, testId, "Какой термин встречается в материале №${index + 1}?", QuestionType.SINGLE_CHOICE, listOf(correct, wrong))
        }
        val test = StudyTest(testId, userId, subjectId, title, sourceText, questions)
        db.studyTests.add(test)
        return test
    }

    override fun generateFlashcards(userId: Long, setId: Long, sourceText: String, count: Int): List<Flashcard> {
        val words = sourceText.split(" ", "\n", ".", ",", ";", ":").map { it.trim() }.filter { it.length >= 5 }.distinct().take(count)
        return words.map { word ->
            Flashcard(db.nextId(), setId, "Что означает термин: $word?", "Ответ сформирован по материалу: $word")
        }.also { db.flashcards.addAll(it) }
    }
}
