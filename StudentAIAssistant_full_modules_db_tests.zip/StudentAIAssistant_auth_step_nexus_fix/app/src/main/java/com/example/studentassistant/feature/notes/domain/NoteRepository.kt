package com.example.studentassistant.feature.notes.domain

interface NoteRepository {
    fun createNote(userId: Long, subjectId: Long?, title: String, content: String, tags: List<String> = emptyList()): Note
    fun getNotes(userId: Long): List<Note>
    fun searchNotes(userId: Long, query: String): List<Note>
    fun saveSummary(noteId: Long, summary: String): Note?
    fun deleteNote(noteId: Long): Boolean
}
