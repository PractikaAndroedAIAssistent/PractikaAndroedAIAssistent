package com.example.studentassistant.feature.grades.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.grades.domain.AnalyticsReport
import com.example.studentassistant.feature.grades.domain.Grade
import com.example.studentassistant.feature.grades.domain.GradeRepository
import com.example.studentassistant.feature.grades.domain.SubjectAverage

class InMemoryGradeRepository(private val db: InMemoryAppDatabase) : GradeRepository {
    override fun addGrade(userId: Long, subjectId: Long, value: Double, weight: Double, type: String): Grade {
        require(value in 1.0..5.0) { "Оценка должна быть от 1 до 5" }
        require(weight > 0.0) { "Вес оценки должен быть больше нуля" }
        return Grade(db.nextId(), userId, subjectId, value, weight, type).also { db.grades.add(it) }
    }

    override fun getGrades(userId: Long): List<Grade> = db.grades.filter { it.userId == userId }

    override fun getSubjectAverage(subjectId: Long): SubjectAverage {
        val grades = db.grades.filter { it.subjectId == subjectId }
        val weightedSum = grades.sumOf { it.value * it.weight }
        val weightSum = grades.sumOf { it.weight }
        val average = if (weightSum == 0.0) 0.0 else weightedSum / weightSum
        return SubjectAverage(subjectId, round1(average), grades.size)
    }

    override fun buildAnalytics(userId: Long): AnalyticsReport {
        val subjectIds = getGrades(userId).map { it.subjectId }.distinct()
        val averages = subjectIds.map { getSubjectAverage(it) }
        val overall = if (averages.isEmpty()) 0.0 else averages.map { it.average }.average()
        val weak = averages.filter { it.average < 3.5 }.map { it.subjectId }
        val strong = averages.filter { it.average >= 4.5 }.map { it.subjectId }
        val recommendation = when {
            averages.isEmpty() -> "Добавьте оценки, чтобы увидеть аналитику."
            weak.isNotEmpty() -> "Есть слабые предметы. Рекомендуется повторить темы и закрыть дедлайны."
            else -> "Успеваемость стабильная. Можно усилить подготовку к экзаменам."
        }
        return AnalyticsReport(userId, round1(overall), averages, weak, strong, recommendation)
    }

    override fun deleteGrade(id: Long): Boolean = db.grades.removeIf { it.id == id }

    private fun round1(value: Double): Double = kotlin.math.round(value * 10.0) / 10.0
}
