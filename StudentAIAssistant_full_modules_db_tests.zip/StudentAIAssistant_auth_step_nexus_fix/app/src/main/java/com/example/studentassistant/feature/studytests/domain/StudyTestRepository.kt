package com.example.studentassistant.feature.studytests.domain

interface StudyTestRepository {
    fun saveTest(test: StudyTest): StudyTest
    fun getTests(userId: Long): List<StudyTest>
    fun submitAttempt(userId: Long, testId: Long, selectedOptionIds: Set<Long>): TestAttempt
    fun getAttempts(userId: Long): List<TestAttempt>
}
