package com.example.studentassistant.feature.pdf.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.pdf.domain.PdfChunk
import com.example.studentassistant.feature.pdf.domain.PdfFile
import com.example.studentassistant.feature.pdf.domain.PdfRepository

class InMemoryPdfRepository(private val db: InMemoryAppDatabase) : PdfRepository {
    override fun uploadPdf(userId: Long, subjectId: Long?, fileName: String, extractedText: String): PdfFile {
        require(fileName.endsWith(".pdf", ignoreCase = true)) { "Файл должен быть PDF" }
        val pdf = PdfFile(db.nextId(), userId, subjectId, fileName, extractedText)
        db.pdfFiles.add(pdf)
        splitIntoChunks(extractedText).forEachIndexed { index, text ->
            db.pdfChunks.add(PdfChunk(db.nextId(), pdf.id, index, text))
        }
        return pdf
    }

    override fun getPdfFiles(userId: Long): List<PdfFile> = db.pdfFiles.filter { it.userId == userId }.sortedBy { it.fileName }
    override fun getChunks(pdfFileId: Long): List<PdfChunk> = db.pdfChunks.filter { it.pdfFileId == pdfFileId }.sortedBy { it.chunkIndex }

    override fun searchChunks(pdfFileId: Long, query: String): List<PdfChunk> {
        val words = query.lowercase().split(" ", ".", ",", "?", "!").filter { it.length > 3 }
        if (words.isEmpty()) return emptyList()
        return getChunks(pdfFileId).filter { chunk ->
            val text = chunk.text.lowercase()
            words.any { text.contains(it) }
        }
    }

    override fun deletePdf(id: Long): Boolean {
        db.pdfChunks.removeIf { it.pdfFileId == id }
        return db.pdfFiles.removeIf { it.id == id }
    }

    private fun splitIntoChunks(text: String, maxChunkSize: Int = 500): List<String> {
        val clean = text.trim()
        if (clean.isBlank()) return listOf("")
        return clean.chunked(maxChunkSize)
    }
}
