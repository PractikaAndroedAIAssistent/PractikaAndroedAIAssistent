package com.example.studentassistant.feature.notifications.domain

enum class NotificationType { LESSON, DEADLINE, FLASHCARD, LOW_GRADE, AI_RECOMMENDATION }

data class NotificationItem(
    val id: Long,
    val userId: Long,
    val type: NotificationType,
    val title: String,
    val message: String,
    val scheduledAt: String,
    val isRead: Boolean = false
)
