package com.example.studentassistant.feature.subjects.domain

interface SubjectRepository {
    fun createSubject(userId: Long, name: String, teacher: String? = null, colorHex: String = "#6C4DFF"): Subject
    fun getSubjects(userId: Long): List<Subject>
    fun updateSubject(subject: Subject): Subject?
    fun deleteSubject(subjectId: Long): Boolean
}
