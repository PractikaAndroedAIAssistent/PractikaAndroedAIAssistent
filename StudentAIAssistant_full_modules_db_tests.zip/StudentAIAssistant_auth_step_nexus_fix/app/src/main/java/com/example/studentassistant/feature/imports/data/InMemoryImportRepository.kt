package com.example.studentassistant.feature.imports.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.deadlines.domain.DeadlinePriority
import com.example.studentassistant.feature.deadlines.domain.DeadlineRepository
import com.example.studentassistant.feature.imports.domain.ImportLog
import com.example.studentassistant.feature.imports.domain.ImportRepository
import com.example.studentassistant.feature.imports.domain.ImportSourceType
import com.example.studentassistant.feature.imports.domain.ImportStatus
import com.example.studentassistant.feature.imports.domain.UniversityImportSource
import com.example.studentassistant.feature.schedule.domain.LessonType
import com.example.studentassistant.feature.schedule.domain.ScheduleRepository

class InMemoryImportRepository(
    private val db: InMemoryAppDatabase,
    private val scheduleRepository: ScheduleRepository,
    private val deadlineRepository: DeadlineRepository
) : ImportRepository {
    override fun createSource(userId: Long, type: ImportSourceType, title: String, url: String?): UniversityImportSource {
        require(title.isNotBlank()) { "Название источника импорта не может быть пустым" }
        return UniversityImportSource(db.nextId(), userId, type, title, url).also { db.importSources.add(it) }
    }

    override fun importDemoData(sourceId: Long, userId: Long, subjectId: Long): ImportLog {
        val sourceExists = db.importSources.any { it.id == sourceId }
        if (!sourceExists) {
            return ImportLog(db.nextId(), sourceId, ImportStatus.ERROR, "Источник импорта не найден", 0).also { db.importLogs.add(it) }
        }
        scheduleRepository.createLesson(userId, subjectId, "Импортированная пара", LessonType.PRACTICE, "2026-05-20", "10:00", "11:30", "305", "Преподаватель")
        deadlineRepository.createDeadline(userId, subjectId, "Импортированный дедлайн", "2026-05-25", DeadlinePriority.HIGH, "Создано из демо-импорта")
        return ImportLog(db.nextId(), sourceId, ImportStatus.SUCCESS, "Импорт выполнен", 2).also { db.importLogs.add(it) }
    }

    override fun getLogs(sourceId: Long): List<ImportLog> = db.importLogs.filter { it.sourceId == sourceId }
}
