package com.example.studentassistant.feature.deadlines.domain

enum class DeadlinePriority { LOW, MEDIUM, HIGH, CRITICAL }
enum class DeadlineStatus { ACTIVE, COMPLETED, OVERDUE }

data class Deadline(
    val id: Long,
    val userId: Long,
    val subjectId: Long,
    val title: String,
    val description: String = "",
    val dueDate: String,
    val dueTime: String? = null,
    val priority: DeadlinePriority = DeadlinePriority.MEDIUM,
    val status: DeadlineStatus = DeadlineStatus.ACTIVE
)
