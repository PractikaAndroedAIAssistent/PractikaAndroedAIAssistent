package com.example.studentassistant.feature.notifications.domain

interface NotificationRepository {
    fun scheduleNotification(userId: Long, type: NotificationType, title: String, message: String, scheduledAt: String): NotificationItem
    fun getNotifications(userId: Long): List<NotificationItem>
    fun getDueNotifications(userId: Long, now: String): List<NotificationItem>
    fun markAsRead(id: Long): NotificationItem?
}
