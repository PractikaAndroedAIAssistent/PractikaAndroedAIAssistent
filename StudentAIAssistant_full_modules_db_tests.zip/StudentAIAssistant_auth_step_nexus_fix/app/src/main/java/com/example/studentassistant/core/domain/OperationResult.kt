package com.example.studentassistant.core.domain

sealed class OperationResult<out T> {
    data class Success<T>(val data: T) : OperationResult<T>()
    data class Error(val message: String) : OperationResult<Nothing>()
}

fun <T> OperationResult<T>.getOrNull(): T? = when (this) {
    is OperationResult.Success -> data
    is OperationResult.Error -> null
}

fun <T> OperationResult<T>.errorOrNull(): String? = when (this) {
    is OperationResult.Success -> null
    is OperationResult.Error -> message
}
