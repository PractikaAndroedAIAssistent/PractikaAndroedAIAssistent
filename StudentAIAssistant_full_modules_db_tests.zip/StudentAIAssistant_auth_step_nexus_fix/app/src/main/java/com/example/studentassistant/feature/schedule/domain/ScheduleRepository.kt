package com.example.studentassistant.feature.schedule.domain

interface ScheduleRepository {
    fun addLesson(item: ScheduleItem): ScheduleItem
    fun createLesson(userId: Long, subjectId: Long, title: String, lessonType: LessonType, date: String, startTime: String, endTime: String, classroom: String? = null, teacher: String? = null): ScheduleItem
    fun getScheduleForDay(userId: Long, date: String): List<ScheduleItem>
    fun getScheduleForSubject(subjectId: Long): List<ScheduleItem>
    fun deleteLesson(id: Long): Boolean
}
