package com.example.studentassistant.feature.pdf.domain

interface PdfRepository {
    fun uploadPdf(userId: Long, subjectId: Long?, fileName: String, extractedText: String): PdfFile
    fun getPdfFiles(userId: Long): List<PdfFile>
    fun getChunks(pdfFileId: Long): List<PdfChunk>
    fun searchChunks(pdfFileId: Long, query: String): List<PdfChunk>
    fun deletePdf(id: Long): Boolean
}
