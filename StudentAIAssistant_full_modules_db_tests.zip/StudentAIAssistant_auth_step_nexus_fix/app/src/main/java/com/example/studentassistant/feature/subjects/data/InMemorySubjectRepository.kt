package com.example.studentassistant.feature.subjects.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.subjects.domain.Subject
import com.example.studentassistant.feature.subjects.domain.SubjectRepository

class InMemorySubjectRepository(private val db: InMemoryAppDatabase) : SubjectRepository {
    override fun createSubject(userId: Long, name: String, teacher: String?, colorHex: String): Subject {
        require(name.isNotBlank()) { "Название предмета не может быть пустым" }
        return Subject(db.nextId(), userId, name.trim(), teacher?.trim(), colorHex).also { db.subjects.add(it) }
    }

    override fun getSubjects(userId: Long): List<Subject> = db.subjects.filter { it.userId == userId }.sortedBy { it.name }

    override fun updateSubject(subject: Subject): Subject? {
        val index = db.subjects.indexOfFirst { it.id == subject.id }
        if (index == -1) return null
        db.subjects[index] = subject
        return subject
    }

    override fun deleteSubject(subjectId: Long): Boolean = db.subjects.removeIf { it.id == subjectId }
}
