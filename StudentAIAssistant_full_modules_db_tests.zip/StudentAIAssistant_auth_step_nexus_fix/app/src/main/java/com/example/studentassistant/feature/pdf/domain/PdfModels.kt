package com.example.studentassistant.feature.pdf.domain

data class PdfFile(
    val id: Long,
    val userId: Long,
    val subjectId: Long?,
    val fileName: String,
    val extractedText: String,
    val uploadedAt: String = ""
)

data class PdfChunk(
    val id: Long,
    val pdfFileId: Long,
    val chunkIndex: Int,
    val text: String
)
