package com.example.studentassistant.core.database

import com.example.studentassistant.feature.ai.data.FakeAiService
import com.example.studentassistant.feature.deadlines.data.InMemoryDeadlineRepository
import com.example.studentassistant.feature.flashcards.data.InMemoryFlashcardRepository
import com.example.studentassistant.feature.grades.data.InMemoryGradeRepository
import com.example.studentassistant.feature.imports.data.InMemoryImportRepository
import com.example.studentassistant.feature.notes.data.InMemoryNoteRepository
import com.example.studentassistant.feature.notifications.data.InMemoryNotificationRepository
import com.example.studentassistant.feature.pdf.data.InMemoryPdfRepository
import com.example.studentassistant.feature.schedule.data.InMemoryScheduleRepository
import com.example.studentassistant.feature.studytests.data.InMemoryStudyTestRepository
import com.example.studentassistant.feature.subjects.data.InMemorySubjectRepository

/** Простая ручная DI-точка для учебного проекта. */
class StudentAssistantContainer(
    val database: InMemoryAppDatabase = InMemoryAppDatabase()
) {
    val subjectRepository = InMemorySubjectRepository(database)
    val scheduleRepository = InMemoryScheduleRepository(database)
    val deadlineRepository = InMemoryDeadlineRepository(database)
    val noteRepository = InMemoryNoteRepository(database)
    val pdfRepository = InMemoryPdfRepository(database)
    val aiService = FakeAiService(database)
    val studyTestRepository = InMemoryStudyTestRepository(database)
    val flashcardRepository = InMemoryFlashcardRepository(database)
    val gradeRepository = InMemoryGradeRepository(database)
    val notificationRepository = InMemoryNotificationRepository(database)
    val importRepository = InMemoryImportRepository(database, scheduleRepository, deadlineRepository)
}
