package com.example.studentassistant.feature.notifications.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.notifications.domain.NotificationItem
import com.example.studentassistant.feature.notifications.domain.NotificationRepository
import com.example.studentassistant.feature.notifications.domain.NotificationType

class InMemoryNotificationRepository(private val db: InMemoryAppDatabase) : NotificationRepository {
    override fun scheduleNotification(userId: Long, type: NotificationType, title: String, message: String, scheduledAt: String): NotificationItem {
        require(title.isNotBlank()) { "Заголовок уведомления не может быть пустым" }
        return NotificationItem(db.nextId(), userId, type, title, message, scheduledAt).also { db.notifications.add(it) }
    }

    override fun getNotifications(userId: Long): List<NotificationItem> = db.notifications.filter { it.userId == userId }.sortedBy { it.scheduledAt }

    override fun getDueNotifications(userId: Long, now: String): List<NotificationItem> =
        db.notifications.filter { it.userId == userId && !it.isRead && it.scheduledAt <= now }.sortedBy { it.scheduledAt }

    override fun markAsRead(id: Long): NotificationItem? {
        val index = db.notifications.indexOfFirst { it.id == id }
        if (index == -1) return null
        val updated = db.notifications[index].copy(isRead = true)
        db.notifications[index] = updated
        return updated
    }
}
