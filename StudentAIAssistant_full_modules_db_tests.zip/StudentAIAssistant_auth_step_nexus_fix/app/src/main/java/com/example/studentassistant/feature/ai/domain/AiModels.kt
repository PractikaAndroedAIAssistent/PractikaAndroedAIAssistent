package com.example.studentassistant.feature.ai.domain

enum class AiRequestType { SUMMARY, TEST_GENERATION, FLASHCARD_GENERATION, PDF_CHAT, RECOMMENDATION }
enum class MessageRole { USER, ASSISTANT, SYSTEM }

data class AiRequest(
    val id: Long,
    val userId: Long,
    val type: AiRequestType,
    val sourceId: Long?,
    val prompt: String
)

data class AiResponse(
    val id: Long,
    val requestId: Long,
    val content: String
)

data class ChatMessage(
    val id: Long,
    val pdfFileId: Long,
    val role: MessageRole,
    val text: String
)
