package com.example.studentassistant.feature.deadlines.domain

interface DeadlineRepository {
    fun createDeadline(userId: Long, subjectId: Long, title: String, dueDate: String, priority: DeadlinePriority = DeadlinePriority.MEDIUM, description: String = ""): Deadline
    fun getActiveDeadlines(userId: Long): List<Deadline>
    fun getDeadlinesForSubject(subjectId: Long): List<Deadline>
    fun completeDeadline(id: Long): Deadline?
    fun getOverdueDeadlines(userId: Long, today: String): List<Deadline>
    fun deleteDeadline(id: Long): Boolean
}
