package com.example.studentassistant.feature.studytests.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.studytests.domain.StudyTest
import com.example.studentassistant.feature.studytests.domain.StudyTestRepository
import com.example.studentassistant.feature.studytests.domain.TestAttempt

class InMemoryStudyTestRepository(private val db: InMemoryAppDatabase) : StudyTestRepository {
    override fun saveTest(test: StudyTest): StudyTest {
        val existingIndex = db.studyTests.indexOfFirst { it.id == test.id }
        if (existingIndex >= 0) db.studyTests[existingIndex] = test else db.studyTests.add(test)
        return test
    }

    override fun getTests(userId: Long): List<StudyTest> = db.studyTests.filter { it.userId == userId }.sortedBy { it.title }

    override fun submitAttempt(userId: Long, testId: Long, selectedOptionIds: Set<Long>): TestAttempt {
        val test = db.studyTests.firstOrNull { it.id == testId } ?: error("Тест не найден")
        val correct = test.questions.count { question ->
            val correctIds = question.options.filter { it.isCorrect }.map { it.id }.toSet()
            correctIds.isNotEmpty() && selectedOptionIds.containsAll(correctIds)
        }
        return TestAttempt(db.nextId(), testId, userId, correct, test.questions.size).also { db.testAttempts.add(it) }
    }

    override fun getAttempts(userId: Long): List<TestAttempt> = db.testAttempts.filter { it.userId == userId }
}
