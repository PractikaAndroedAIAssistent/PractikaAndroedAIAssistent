package com.example.studentassistant.core.database

import com.example.studentassistant.feature.ai.domain.AiRequest
import com.example.studentassistant.feature.ai.domain.AiResponse
import com.example.studentassistant.feature.ai.domain.ChatMessage
import com.example.studentassistant.feature.deadlines.domain.Deadline
import com.example.studentassistant.feature.flashcards.domain.Flashcard
import com.example.studentassistant.feature.flashcards.domain.FlashcardSet
import com.example.studentassistant.feature.grades.domain.Grade
import com.example.studentassistant.feature.imports.domain.ImportLog
import com.example.studentassistant.feature.imports.domain.UniversityImportSource
import com.example.studentassistant.feature.notes.domain.Note
import com.example.studentassistant.feature.notifications.domain.NotificationItem
import com.example.studentassistant.feature.pdf.domain.PdfChunk
import com.example.studentassistant.feature.pdf.domain.PdfFile
import com.example.studentassistant.feature.schedule.domain.ScheduleItem
import com.example.studentassistant.feature.studytests.domain.StudyTest
import com.example.studentassistant.feature.studytests.domain.TestAttempt
import com.example.studentassistant.feature.subjects.domain.Subject

/**
 * Учебная локальная БД без внешних зависимостей.
 * Нужна, чтобы проект стабильно собирался даже через закрытый Nexus.
 * Позже этот класс можно заменить на Room Database + DAO без изменения domain-моделей.
 */
class InMemoryAppDatabase {
    val subjects = mutableListOf<Subject>()
    val scheduleItems = mutableListOf<ScheduleItem>()
    val deadlines = mutableListOf<Deadline>()
    val notes = mutableListOf<Note>()
    val pdfFiles = mutableListOf<PdfFile>()
    val pdfChunks = mutableListOf<PdfChunk>()
    val aiRequests = mutableListOf<AiRequest>()
    val aiResponses = mutableListOf<AiResponse>()
    val chatMessages = mutableListOf<ChatMessage>()
    val studyTests = mutableListOf<StudyTest>()
    val testAttempts = mutableListOf<TestAttempt>()
    val flashcardSets = mutableListOf<FlashcardSet>()
    val flashcards = mutableListOf<Flashcard>()
    val grades = mutableListOf<Grade>()
    val notifications = mutableListOf<NotificationItem>()
    val importSources = mutableListOf<UniversityImportSource>()
    val importLogs = mutableListOf<ImportLog>()

    private var idCounter = 1L

    fun nextId(): Long = idCounter++

    fun clear() {
        subjects.clear()
        scheduleItems.clear()
        deadlines.clear()
        notes.clear()
        pdfFiles.clear()
        pdfChunks.clear()
        aiRequests.clear()
        aiResponses.clear()
        chatMessages.clear()
        studyTests.clear()
        testAttempts.clear()
        flashcardSets.clear()
        flashcards.clear()
        grades.clear()
        notifications.clear()
        importSources.clear()
        importLogs.clear()
        idCounter = 1L
    }
}
