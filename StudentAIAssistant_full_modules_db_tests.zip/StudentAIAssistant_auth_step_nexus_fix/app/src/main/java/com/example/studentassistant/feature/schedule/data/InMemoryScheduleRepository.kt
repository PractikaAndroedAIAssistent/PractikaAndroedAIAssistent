package com.example.studentassistant.feature.schedule.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.schedule.domain.LessonType
import com.example.studentassistant.feature.schedule.domain.ScheduleItem
import com.example.studentassistant.feature.schedule.domain.ScheduleRepository

class InMemoryScheduleRepository(private val db: InMemoryAppDatabase) : ScheduleRepository {
    override fun addLesson(item: ScheduleItem): ScheduleItem {
        val saved = item.copy(id = if (item.id == 0L) db.nextId() else item.id)
        db.scheduleItems.add(saved)
        return saved
    }

    override fun createLesson(userId: Long, subjectId: Long, title: String, lessonType: LessonType, date: String, startTime: String, endTime: String, classroom: String?, teacher: String?): ScheduleItem {
        require(title.isNotBlank()) { "Название занятия не может быть пустым" }
        return addLesson(ScheduleItem(0, userId, subjectId, title.trim(), lessonType, date, startTime, endTime, classroom, teacher))
    }

    override fun getScheduleForDay(userId: Long, date: String): List<ScheduleItem> =
        db.scheduleItems.filter { it.userId == userId && it.date == date }.sortedBy { it.startTime }

    override fun getScheduleForSubject(subjectId: Long): List<ScheduleItem> =
        db.scheduleItems.filter { it.subjectId == subjectId }.sortedWith(compareBy<ScheduleItem> { it.date }.thenBy { it.startTime })

    override fun deleteLesson(id: Long): Boolean = db.scheduleItems.removeIf { it.id == id }
}
