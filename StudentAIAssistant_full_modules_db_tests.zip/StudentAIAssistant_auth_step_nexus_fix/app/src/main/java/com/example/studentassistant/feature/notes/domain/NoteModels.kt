package com.example.studentassistant.feature.notes.domain

data class Note(
    val id: Long,
    val userId: Long,
    val subjectId: Long?,
    val title: String,
    val content: String,
    val tags: List<String> = emptyList(),
    val summary: String? = null,
    val createdAt: String = "",
    val updatedAt: String = ""
)
