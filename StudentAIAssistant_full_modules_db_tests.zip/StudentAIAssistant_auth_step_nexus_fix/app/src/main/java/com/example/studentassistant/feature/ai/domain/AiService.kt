package com.example.studentassistant.feature.ai.domain

import com.example.studentassistant.feature.flashcards.domain.Flashcard
import com.example.studentassistant.feature.studytests.domain.StudyTest

interface AiService {
    fun summarize(userId: Long, sourceId: Long?, text: String): AiResponse
    fun answerByPdf(userId: Long, pdfFileId: Long, question: String): AiResponse
    fun generateTest(userId: Long, subjectId: Long?, title: String, sourceText: String, questionsCount: Int): StudyTest
    fun generateFlashcards(userId: Long, setId: Long, sourceText: String, count: Int): List<Flashcard>
}
