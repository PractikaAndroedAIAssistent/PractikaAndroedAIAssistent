package com.example.studentassistant.feature.grades.domain

data class Grade(
    val id: Long,
    val userId: Long,
    val subjectId: Long,
    val value: Double,
    val weight: Double = 1.0,
    val type: String = "Оценка",
    val date: String = "",
    val comment: String? = null
)

data class SubjectAverage(
    val subjectId: Long,
    val average: Double,
    val count: Int
)

data class AnalyticsReport(
    val userId: Long,
    val overallAverage: Double,
    val subjectAverages: List<SubjectAverage>,
    val weakSubjectIds: List<Long>,
    val strongSubjectIds: List<Long>,
    val recommendation: String
)
