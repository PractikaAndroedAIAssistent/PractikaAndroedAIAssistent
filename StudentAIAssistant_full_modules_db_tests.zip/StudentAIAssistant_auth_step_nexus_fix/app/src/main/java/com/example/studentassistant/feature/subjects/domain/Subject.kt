package com.example.studentassistant.feature.subjects.domain

data class Subject(
    val id: Long,
    val userId: Long,
    val name: String,
    val teacher: String? = null,
    val colorHex: String = "#6C4DFF"
)
