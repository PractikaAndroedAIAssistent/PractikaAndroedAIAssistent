package com.example.studentassistant.feature.notes.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.notes.domain.Note
import com.example.studentassistant.feature.notes.domain.NoteRepository

class InMemoryNoteRepository(private val db: InMemoryAppDatabase) : NoteRepository {
    override fun createNote(userId: Long, subjectId: Long?, title: String, content: String, tags: List<String>): Note {
        require(title.isNotBlank()) { "Заголовок конспекта не может быть пустым" }
        require(content.isNotBlank()) { "Текст конспекта не может быть пустым" }
        return Note(db.nextId(), userId, subjectId, title.trim(), content.trim(), tags.map { it.trim() }.filter { it.isNotBlank() }).also { db.notes.add(it) }
    }

    override fun getNotes(userId: Long): List<Note> = db.notes.filter { it.userId == userId }.sortedBy { it.title }

    override fun searchNotes(userId: Long, query: String): List<Note> {
        val normalized = query.trim().lowercase()
        if (normalized.isBlank()) return getNotes(userId)
        return db.notes.filter { note ->
            note.userId == userId && (
                note.title.lowercase().contains(normalized) ||
                note.content.lowercase().contains(normalized) ||
                note.tags.any { it.lowercase().contains(normalized) }
            )
        }
    }

    override fun saveSummary(noteId: Long, summary: String): Note? {
        val index = db.notes.indexOfFirst { it.id == noteId }
        if (index == -1) return null
        val updated = db.notes[index].copy(summary = summary)
        db.notes[index] = updated
        return updated
    }

    override fun deleteNote(noteId: Long): Boolean = db.notes.removeIf { it.id == noteId }
}
