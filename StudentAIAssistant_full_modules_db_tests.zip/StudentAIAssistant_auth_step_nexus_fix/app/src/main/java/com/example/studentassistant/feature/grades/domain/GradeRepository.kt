package com.example.studentassistant.feature.grades.domain

interface GradeRepository {
    fun addGrade(userId: Long, subjectId: Long, value: Double, weight: Double = 1.0, type: String = "Оценка"): Grade
    fun getGrades(userId: Long): List<Grade>
    fun getSubjectAverage(subjectId: Long): SubjectAverage
    fun buildAnalytics(userId: Long): AnalyticsReport
    fun deleteGrade(id: Long): Boolean
}
