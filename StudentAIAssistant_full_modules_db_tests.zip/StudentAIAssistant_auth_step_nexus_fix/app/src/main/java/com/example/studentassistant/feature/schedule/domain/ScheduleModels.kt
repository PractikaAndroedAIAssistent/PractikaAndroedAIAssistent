package com.example.studentassistant.feature.schedule.domain

enum class LessonType { LECTURE, PRACTICE, LAB, SEMINAR, EXAM, CREDIT }

data class ScheduleItem(
    val id: Long,
    val userId: Long,
    val subjectId: Long,
    val title: String,
    val lessonType: LessonType,
    val date: String,
    val startTime: String,
    val endTime: String,
    val classroom: String? = null,
    val teacher: String? = null
)
