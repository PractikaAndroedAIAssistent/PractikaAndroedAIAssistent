package com.example.studentassistant.feature.flashcards.domain

interface FlashcardRepository {
    fun createSet(userId: Long, subjectId: Long?, title: String): FlashcardSet
    fun addCard(setId: Long, question: String, answer: String): Flashcard
    fun getSets(userId: Long): List<FlashcardSet>
    fun getCards(setId: Long): List<Flashcard>
    fun getDueCards(userId: Long, day: Int): List<Flashcard>
    fun reviewCard(cardId: Long, level: KnowledgeLevel, currentDay: Int): Flashcard?
}
