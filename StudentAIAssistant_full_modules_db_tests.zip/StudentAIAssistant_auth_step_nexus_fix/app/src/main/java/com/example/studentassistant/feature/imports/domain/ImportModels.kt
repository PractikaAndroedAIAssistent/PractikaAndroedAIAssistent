package com.example.studentassistant.feature.imports.domain

enum class ImportSourceType { UNIVERSITY_API, CSV_FILE, ICS_FILE, MANUAL }
enum class ImportStatus { SUCCESS, PARTIAL, ERROR }

data class UniversityImportSource(
    val id: Long,
    val userId: Long,
    val type: ImportSourceType,
    val title: String,
    val url: String? = null,
    val isEnabled: Boolean = true
)

data class ImportLog(
    val id: Long,
    val sourceId: Long,
    val status: ImportStatus,
    val message: String,
    val importedItemsCount: Int
)
