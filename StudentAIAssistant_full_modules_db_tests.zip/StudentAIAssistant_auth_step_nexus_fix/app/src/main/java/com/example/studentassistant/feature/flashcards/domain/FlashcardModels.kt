package com.example.studentassistant.feature.flashcards.domain

enum class KnowledgeLevel { DONT_KNOW, BAD, NORMAL, GOOD, EXCELLENT }

data class FlashcardSet(
    val id: Long,
    val userId: Long,
    val subjectId: Long?,
    val title: String
)

data class Flashcard(
    val id: Long,
    val setId: Long,
    val question: String,
    val answer: String,
    val knowledgeLevel: KnowledgeLevel = KnowledgeLevel.DONT_KNOW,
    val nextReviewDay: Int = 0
)
