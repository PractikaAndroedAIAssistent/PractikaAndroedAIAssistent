package com.example.studentassistant.feature.studytests.domain

enum class QuestionType { SINGLE_CHOICE, MULTIPLE_CHOICE, TRUE_FALSE, OPEN }

data class AnswerOption(
    val id: Long,
    val questionId: Long,
    val text: String,
    val isCorrect: Boolean
)

data class TestQuestion(
    val id: Long,
    val testId: Long,
    val text: String,
    val type: QuestionType,
    val options: List<AnswerOption> = emptyList(),
    val correctTextAnswer: String? = null
)

data class StudyTest(
    val id: Long,
    val userId: Long,
    val subjectId: Long?,
    val title: String,
    val sourceText: String,
    val questions: List<TestQuestion> = emptyList()
)

data class TestAttempt(
    val id: Long,
    val testId: Long,
    val userId: Long,
    val correctAnswers: Int,
    val totalQuestions: Int
) {
    val percent: Int
        get() = if (totalQuestions == 0) 0 else (correctAnswers * 100) / totalQuestions
}
