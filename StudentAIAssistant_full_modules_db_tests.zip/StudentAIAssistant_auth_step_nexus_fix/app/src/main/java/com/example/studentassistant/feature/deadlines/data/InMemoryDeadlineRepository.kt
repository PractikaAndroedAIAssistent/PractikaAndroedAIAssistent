package com.example.studentassistant.feature.deadlines.data

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.deadlines.domain.Deadline
import com.example.studentassistant.feature.deadlines.domain.DeadlinePriority
import com.example.studentassistant.feature.deadlines.domain.DeadlineRepository
import com.example.studentassistant.feature.deadlines.domain.DeadlineStatus

class InMemoryDeadlineRepository(private val db: InMemoryAppDatabase) : DeadlineRepository {
    override fun createDeadline(userId: Long, subjectId: Long, title: String, dueDate: String, priority: DeadlinePriority, description: String): Deadline {
        require(title.isNotBlank()) { "Название дедлайна не может быть пустым" }
        return Deadline(db.nextId(), userId, subjectId, title.trim(), description, dueDate, priority = priority).also { db.deadlines.add(it) }
    }

    override fun getActiveDeadlines(userId: Long): List<Deadline> =
        db.deadlines.filter { it.userId == userId && it.status == DeadlineStatus.ACTIVE }.sortedWith(compareBy<Deadline> { it.dueDate }.thenBy { it.priority.ordinal })

    override fun getDeadlinesForSubject(subjectId: Long): List<Deadline> = db.deadlines.filter { it.subjectId == subjectId }.sortedBy { it.dueDate }

    override fun completeDeadline(id: Long): Deadline? {
        val index = db.deadlines.indexOfFirst { it.id == id }
        if (index == -1) return null
        val completed = db.deadlines[index].copy(status = DeadlineStatus.COMPLETED)
        db.deadlines[index] = completed
        return completed
    }

    override fun getOverdueDeadlines(userId: Long, today: String): List<Deadline> =
        db.deadlines.filter { it.userId == userId && it.status == DeadlineStatus.ACTIVE && it.dueDate < today }.map { it.copy(status = DeadlineStatus.OVERDUE) }

    override fun deleteDeadline(id: Long): Boolean = db.deadlines.removeIf { it.id == id }
}
