package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.grades.data.InMemoryGradeRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class GradesAnalyticsModuleTest {
    private lateinit var repository: InMemoryGradeRepository

    @Before
    fun setup() {
        repository = InMemoryGradeRepository(InMemoryAppDatabase())
    }

    @Test
    fun getSubjectAverage_calculatesWeightedAverage() {
        repository.addGrade(1, 10, value = 5.0, weight = 2.0)
        repository.addGrade(1, 10, value = 3.0, weight = 1.0)
        val average = repository.getSubjectAverage(10)
        assertEquals(4.3, average.average, 0.01)
    }

    @Test
    fun buildAnalytics_detectsWeakAndStrongSubjects() {
        repository.addGrade(1, 10, 5.0)
        repository.addGrade(1, 10, 4.0)
        repository.addGrade(1, 20, 3.0)
        val report = repository.buildAnalytics(1)
        assertTrue(report.strongSubjectIds.contains(10))
        assertTrue(report.weakSubjectIds.contains(20))
    }
}
