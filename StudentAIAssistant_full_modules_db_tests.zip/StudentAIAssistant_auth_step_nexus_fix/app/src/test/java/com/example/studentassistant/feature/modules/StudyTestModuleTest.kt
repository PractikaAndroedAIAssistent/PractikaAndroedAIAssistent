package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.ai.data.FakeAiService
import com.example.studentassistant.feature.studytests.data.InMemoryStudyTestRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class StudyTestModuleTest {
    private lateinit var db: InMemoryAppDatabase
    private lateinit var aiService: FakeAiService
    private lateinit var repository: InMemoryStudyTestRepository

    @Before
    fun setup() {
        db = InMemoryAppDatabase()
        aiService = FakeAiService(db)
        repository = InMemoryStudyTestRepository(db)
    }

    @Test
    fun generateTest_createsRequestedQuestions() {
        val test = aiService.generateTest(1, 2, "Тест", "модель алгоритм система функция граф матрица", 3)
        assertEquals(3, test.questions.size)
        assertTrue(repository.getTests(1).contains(test))
    }

    @Test
    fun submitAttempt_calculatesPercent() {
        val test = aiService.generateTest(1, 2, "Тест", "модель алгоритм система", 2)
        val correctIds = test.questions.flatMap { question -> question.options.filter { it.isCorrect }.map { it.id } }.toSet()
        val attempt = repository.submitAttempt(1, test.id, correctIds)
        assertEquals(100, attempt.percent)
    }
}
