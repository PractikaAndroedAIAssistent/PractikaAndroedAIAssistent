package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.schedule.data.InMemoryScheduleRepository
import com.example.studentassistant.feature.schedule.domain.LessonType
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class ScheduleModuleTest {
    private lateinit var repository: InMemoryScheduleRepository

    @Before
    fun setup() {
        repository = InMemoryScheduleRepository(InMemoryAppDatabase())
    }

    @Test
    fun getScheduleForDay_returnsLessonsSortedByTime() {
        repository.createLesson(1, 10, "Поздняя пара", LessonType.LECTURE, "2026-05-20", "12:00", "13:30")
        repository.createLesson(1, 10, "Ранняя пара", LessonType.PRACTICE, "2026-05-20", "08:30", "10:00")

        val day = repository.getScheduleForDay(1, "2026-05-20")

        assertEquals("Ранняя пара", day.first().title)
        assertEquals("Поздняя пара", day.last().title)
    }
}
