package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.deadlines.data.InMemoryDeadlineRepository
import com.example.studentassistant.feature.imports.data.InMemoryImportRepository
import com.example.studentassistant.feature.imports.domain.ImportSourceType
import com.example.studentassistant.feature.imports.domain.ImportStatus
import com.example.studentassistant.feature.schedule.data.InMemoryScheduleRepository
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class ImportModuleTest {
    private lateinit var db: InMemoryAppDatabase
    private lateinit var scheduleRepository: InMemoryScheduleRepository
    private lateinit var deadlineRepository: InMemoryDeadlineRepository
    private lateinit var repository: InMemoryImportRepository

    @Before
    fun setup() {
        db = InMemoryAppDatabase()
        scheduleRepository = InMemoryScheduleRepository(db)
        deadlineRepository = InMemoryDeadlineRepository(db)
        repository = InMemoryImportRepository(db, scheduleRepository, deadlineRepository)
    }

    @Test
    fun importDemoData_createsScheduleAndDeadline() {
        val source = repository.createSource(1, ImportSourceType.MANUAL, "ЛК вуза")
        val log = repository.importDemoData(source.id, userId = 1, subjectId = 10)
        assertEquals(ImportStatus.SUCCESS, log.status)
        assertEquals(1, scheduleRepository.getScheduleForDay(1, "2026-05-20").size)
        assertEquals(1, deadlineRepository.getActiveDeadlines(1).size)
    }
}
