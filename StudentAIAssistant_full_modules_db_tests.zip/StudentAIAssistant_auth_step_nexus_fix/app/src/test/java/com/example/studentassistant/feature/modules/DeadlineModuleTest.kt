package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.deadlines.data.InMemoryDeadlineRepository
import com.example.studentassistant.feature.deadlines.domain.DeadlinePriority
import com.example.studentassistant.feature.deadlines.domain.DeadlineStatus
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class DeadlineModuleTest {
    private lateinit var repository: InMemoryDeadlineRepository

    @Before
    fun setup() {
        repository = InMemoryDeadlineRepository(InMemoryAppDatabase())
    }

    @Test
    fun completeDeadline_changesStatusToCompleted() {
        val deadline = repository.createDeadline(1, 2, "Сдать отчёт", "2026-05-25", DeadlinePriority.HIGH)
        val completed = repository.completeDeadline(deadline.id)
        assertEquals(DeadlineStatus.COMPLETED, completed?.status)
    }

    @Test
    fun getOverdueDeadlines_returnsOnlyPastActiveDeadlines() {
        repository.createDeadline(1, 2, "Старый", "2026-05-01")
        repository.createDeadline(1, 2, "Будущий", "2026-05-30")

        val overdue = repository.getOverdueDeadlines(1, "2026-05-15")

        assertEquals(1, overdue.size)
        assertEquals("Старый", overdue.first().title)
    }
}
