package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.notifications.data.InMemoryNotificationRepository
import com.example.studentassistant.feature.notifications.domain.NotificationType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NotificationModuleTest {
    private lateinit var repository: InMemoryNotificationRepository

    @Before
    fun setup() {
        repository = InMemoryNotificationRepository(InMemoryAppDatabase())
    }

    @Test
    fun getDueNotifications_returnsUnreadNotificationsBeforeNow() {
        val due = repository.scheduleNotification(1, NotificationType.DEADLINE, "Дедлайн", "Сдать отчёт", "2026-05-15T10:00")
        repository.scheduleNotification(1, NotificationType.LESSON, "Пара", "Через час", "2026-05-20T10:00")
        assertEquals(1, repository.getDueNotifications(1, "2026-05-16T10:00").size)
        repository.markAsRead(due.id)
        assertTrue(repository.getDueNotifications(1, "2026-05-16T10:00").isEmpty())
    }
}
