package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.ai.data.FakeAiService
import com.example.studentassistant.feature.pdf.data.InMemoryPdfRepository
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class PdfAiModuleTest {
    private lateinit var db: InMemoryAppDatabase
    private lateinit var pdfRepository: InMemoryPdfRepository
    private lateinit var aiService: FakeAiService

    @Before
    fun setup() {
        db = InMemoryAppDatabase()
        pdfRepository = InMemoryPdfRepository(db)
        aiService = FakeAiService(db)
    }

    @Test
    fun uploadPdf_createsChunks() {
        val pdf = pdfRepository.uploadPdf(1, null, "lecture.pdf", "Симплекс метод используется для оптимизации. ".repeat(30))
        assertEquals("lecture.pdf", pdf.fileName)
        assertTrue(pdfRepository.getChunks(pdf.id).isNotEmpty())
    }

    @Test
    fun answerByPdf_returnsAnswerWhenTextExists() {
        val pdf = pdfRepository.uploadPdf(1, null, "lecture.pdf", "Симплекс метод применяется в линейном программировании.")
        val answer = aiService.answerByPdf(1, pdf.id, "Что такое симплекс?")
        assertTrue(answer.content.contains("Симплекс", ignoreCase = true))
    }

    @Test
    fun answerByPdf_returnsNotEnoughInfoWhenTextMissing() {
        val pdf = pdfRepository.uploadPdf(1, null, "lecture.pdf", "Тут только расписание занятий.")
        val answer = aiService.answerByPdf(1, pdf.id, "Что такое квантовая физика?")
        assertEquals("В загруженном материале нет достаточной информации для ответа на этот вопрос.", answer.content)
    }
}
