package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.subjects.data.InMemorySubjectRepository
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class SubjectModuleTest {
    private lateinit var repository: InMemorySubjectRepository

    @Before
    fun setup() {
        repository = InMemorySubjectRepository(InMemoryAppDatabase())
    }

    @Test
    fun createSubject_savesSubjectForUser() {
        val subject = repository.createSubject(userId = 1, name = "МДК 02.02", teacher = "Иванов")
        assertEquals("МДК 02.02", subject.name)
        assertEquals(1, repository.getSubjects(1).size)
    }

    @Test
    fun deleteSubject_removesSubject() {
        val subject = repository.createSubject(1, "Математика")
        assertTrue(repository.deleteSubject(subject.id))
        assertTrue(repository.getSubjects(1).isEmpty())
    }
}
