package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.flashcards.data.InMemoryFlashcardRepository
import com.example.studentassistant.feature.flashcards.domain.KnowledgeLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class FlashcardModuleTest {
    private lateinit var repository: InMemoryFlashcardRepository

    @Before
    fun setup() {
        repository = InMemoryFlashcardRepository(InMemoryAppDatabase())
    }

    @Test
    fun createSetAndCard_savesFlashcard() {
        val set = repository.createSet(1, 2, "Термины")
        repository.addCard(set.id, "Что такое модель?", "Упрощённое представление объекта")
        assertEquals(1, repository.getCards(set.id).size)
    }

    @Test
    fun reviewCard_setsNextReviewDayByLevel() {
        val set = repository.createSet(1, null, "Повторение")
        val card = repository.addCard(set.id, "Вопрос", "Ответ")
        val reviewed = repository.reviewCard(card.id, KnowledgeLevel.GOOD, currentDay = 10)
        assertEquals(17, reviewed?.nextReviewDay)
        assertTrue(repository.getDueCards(1, day = 16).isEmpty())
        assertEquals(1, repository.getDueCards(1, day = 17).size)
    }
}
