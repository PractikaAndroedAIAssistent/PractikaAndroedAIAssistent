package com.example.studentassistant.feature.modules

import com.example.studentassistant.core.database.InMemoryAppDatabase
import com.example.studentassistant.feature.notes.data.InMemoryNoteRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class NotesModuleTest {
    private lateinit var repository: InMemoryNoteRepository

    @Before
    fun setup() {
        repository = InMemoryNoteRepository(InMemoryAppDatabase())
    }

    @Test
    fun searchNotes_findsByTitleContentAndTags() {
        repository.createNote(1, 2, "Симплекс", "Метод решения задач", listOf("моделирование"))
        repository.createNote(1, 2, "Git", "Коммиты и ветки", listOf("инструменты"))

        assertEquals(1, repository.searchNotes(1, "симплекс").size)
        assertEquals(1, repository.searchNotes(1, "ветки").size)
        assertEquals(1, repository.searchNotes(1, "инструменты").size)
    }

    @Test
    fun saveSummary_updatesNoteSummary() {
        val note = repository.createNote(1, null, "PDF", "Большой текст")
        val updated = repository.saveSummary(note.id, "Кратко")
        assertEquals("Кратко", updated?.summary)
        assertTrue(repository.getNotes(1).first().summary == "Кратко")
    }
}
