package com.example.studentassistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.studentassistant.ui.components.QuickActionCard
import com.example.studentassistant.ui.theme.BackgroundLight
import com.example.studentassistant.ui.theme.BlueSoft
import com.example.studentassistant.ui.theme.GreenSoft
import com.example.studentassistant.ui.theme.PurpleLight
import com.example.studentassistant.ui.theme.TextSecondary

@Composable
fun ProfileScreen() {
    Column(modifier = Modifier.fillMaxSize().background(BackgroundLight).padding(top = 44.dp, start = 20.dp, end = 20.dp)) {
        Text("Профиль", style = MaterialTheme.typography.headlineMedium)
        Text("Студент • 3 курс • ИСП", color = TextSecondary, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
        QuickActionCard("Мой профиль", "Данные студента", Icons.Rounded.Person, PurpleLight)
        QuickActionCard("Уведомления", "Пары, дедлайны, карточки", Icons.Rounded.Notifications, BlueSoft, modifier = Modifier.padding(top = 12.dp))
        QuickActionCard("Настройки", "Тема, язык, AI", Icons.Rounded.Settings, GreenSoft, modifier = Modifier.padding(top = 12.dp))
    }
}
